DROP TABLE IF EXISTS `#__jhackguard_ip_filters`;
DROP TABLE IF EXISTS `#__jhackguard_input_filters`;
DROP TABLE IF EXISTS `#__jhackguard_output_filters`;
DROP TABLE IF EXISTS `#__jhackguard_bot_scout`;
DROP TABLE IF EXISTS `#__jhackguard_logs`;
DROP TABLE IF EXISTS `#__jhackguard_scan_hits`;
DROP TABLE IF EXISTS `#__jhackguard_scan_files`;
